var cred = {
    username: '{{username}}',
    password: '{{password}}'
};